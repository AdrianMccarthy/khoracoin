1.0.0.0 changes
=============
- Crypto was officially released!
